﻿using System;
using System.Collections.Generic;
using System.Text;

namespace demo_8.com.comform
{
    class Student
    {
        int age;
        public Student()
        {
            age = 0;
        }

        public Student(int i)
        {
            age = i;
        }

        internal void karan()
        {
            Console.WriteLine(age);
        }

        internal void karan(string i)
        {
            Console.WriteLine(i + age);
        }

        internal void karan(string i , int j)
        {
            age = j;
            Console.WriteLine(i+j);
        }


    }
}
