﻿using System;
using demo_8.com.comform;

namespace demo_8
{
    class Program
    {
        //overloded methods
        //overloded contructors
        static void Main(string[] args)
        {
            Student st = new Student();
            st.karan("your age is ",17);
        }
    }
}
