﻿using System;
using System.Collections.Generic;
using System.Text;

namespace demo_7.com.comform
{
    class student
    {
        public student(string i)
        {
            
            Console.WriteLine($"Hello {i}.");
            
        }
    }
}
