﻿using System;
using demo_7.com.comform;

namespace demo_7
{
    class Program
    {
        static void Main(string[] args)
        {
            //cunstructor  
            // ctor + tab +tab e class ma j bane.
            //cunstructor e starting ma j exicute thay ,  public and privet eva prakar, jo perameter na hoy to default kahevay and jo hoy to perameter aapavu pade.
            string name;
            Console.Write("Enter Your Name : ");
            name = Console.ReadLine();
            student st = new student(name);

        }
    }
}
