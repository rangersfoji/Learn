﻿using System;
using System.Collections.Generic;
using System.Text;

namespace demo_5.com.studentmanagement
{
    class Student
    {
        private string name;
        private int age;
        private int marks;

        public void Checknamedata(string i)
        {
            if (!string.IsNullOrEmpty(i))
            {
                name = i;
            }
            else
            {
                Console.WriteLine("you can not put empty space in name!!!");
            }
        }

        public void Checkagedata(int i)
        {
            if (i>0)
            {
                age = i;
            }
            else
            {
                Console.WriteLine("you enter invalid age!!!");
            }
        }

        public void Checkmarksdata(int i)
        {
            if (i>0)
            {
                marks = i;
            }
            else
            {
                Console.WriteLine("you eneter invalid marks!!!");
            }
        }

        public void Display()
        {
            Console.WriteLine($"name:{name} , age:{age} , marks:{marks}");
        }
        
    }
}
