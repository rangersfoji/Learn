﻿using System;
using demo_5.com.studentmanagement;

namespace demo_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //encapsulation for security to prevent our program to crash by app user.
            // see student class
            Student st = new Student();
            st.Checknamedata("karan");
            st.Checkagedata(10);
            st.Checkmarksdata(10);
            st.Display();
        }
    }
}
