﻿

using System;
using demo_6.com.comfom;

namespace demo_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Stu st = new Stu();
            st.display(10);   // # protected

            // public,private,protected,internal,internal protected
            
            
            
        }
        
    }
}
