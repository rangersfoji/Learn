﻿using System;
using System.Collections.Generic;
using System.Text;

namespace demo_6.com.comfom
{
    class Student
    {
       protected int age;
    }

    class Stu : Student
    {
        public void display(int a)
        {
            age = a;
            Console.WriteLine(age);
        }
    }
}
