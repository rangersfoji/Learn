﻿using System;

namespace first
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("hello karan sir , how are you?");
            //Console.ReadLine();

            //int age = 17;
            //age = 18;
            //age = age + 1;
            //age++;
            //age--;


            //Console.WriteLine(age);
            //Console.ReadLine();

            //string name = "karan";

            //Console.WriteLine(name);
            //Console.ReadLine();

            //int karan_age = 17;
            //int neel_age = 18;

            //int sum = karan_age + neel_age;
            //int mul = karan_age * neel_age;
            //int min = karan_age - neel_age;

            //Console.WriteLine(sum);
            //Console.WriteLine(mul);
            //Console.WriteLine(min);
            //Console.ReadLine();

            //Console.WriteLine($"sum = {sum} , mul = {mul} , min = {min} .");
            //Console.ReadLine();

            //Console.WriteLine("sum = {0} , mul = {1} , min = {2} .", sum, mul, min);
            //Console.ReadLine();

            //Console.WriteLine("sum = {0} \nmul = {1} \nmin = {2} .", sum, mul, min);
            //Console.ReadLine();

            //Console.WriteLine("sum = {0} , mul = {1} , min = {2} .", karan_age + neel_age, karan_age * neel_age, karan_age - neel_age);
            //Console.ReadLine();

            //string firstname = "karan";
            //string lastname = "patel";

            //Console.WriteLine(firstname);
            //Console.WriteLine(lastname);
            //Console.ReadLine();

            //Console.WriteLine($"{firstname} {lastname}.");
            //Console.ReadLine();

            //string fullname = firstname + " " + lastname + ".";


            //Console.WriteLine(fullname);
            //Console.ReadLine();

            //string fullname2 = $"{firstname} {lastname}.";

            //Console.WriteLine(fullname2);
            //Console.ReadLine();



            //double point_value = 1.2646;   // point pachi 14 data (32 bit)

            //Console.WriteLine(point_value);
            //Console.ReadLine();

            //float vadhare_point_value = 1.565f;  // point pachi 6 data (64 bit)

            //Console.WriteLine(vadhare_point_value);
            //Console.ReadLine();

            //decimal sauthi_vadhare_point_value = 1.1234564897989849848949m;  // point pachi 28 data (128 bit)

            //Console.WriteLine(sauthi_vadhare_point_value);
            //Console.ReadLine();


            //string username;
            //Console.WriteLine("enter your name : ");
            //username = Console.ReadLine();
            //Console.WriteLine($"hiii {username} , how are you sir?");
            //Console.ReadLine();

            //string username2;
            //Console.Write("enter your name : ");  // writeline na badale write to   curser bajuma aave
            //username2 = Console.ReadLine();
            //Console.WriteLine($"hiii {username2} , how are you sir?");
            //Console.ReadLine();

            //Console.WriteLine("1");
            //Console.Write("2");
            //Console.WriteLine("3");
            //Console.Write("4");
            //Console.ReadLine();


            //int user_age;
            //Console.Write("please enter your age : ");

            //user_age = int.Parse(Console.ReadLine());   // int.Parse() , float.Parse()
            //Console.WriteLine($"hii {username} you age is {user_age}.");
            //Console.ReadLine();

            // tips
            // 1. cw + tab + tab
            // 2. con + tab = console 
            // 3. use tab 
            // 4. ctr + .  (using system )
            // 5. ctr + k,i (variable type and detail)
            // 6. ctr + space (list pachulavava)
            // 7. ctr + l (line cut thay)  and ctr + v many times
            /// 8. ctr + enter 
            /// 9. alt + up  (line replace karavamate)
            /// 10. shift + alt +  up/down/left/right ( same code ma amuk vastu badalava)

            //if (2 > 5)
            //{
            //    Console.WriteLine("two is less than five.");
            //    Console.ReadLine();
            //        }
            //else
            //{
            //    Console.WriteLine("two is not less than five.");
            //}

            //int user1_age;
            //Console.Write("enter your age : ");
            //user1_age = int.Parse(Console.ReadLine());
            //int user1_money;
            //Console.Write("enter your money : ");
            //user1_money = int.Parse(Console.ReadLine());

            //if (user1_age > 10)
            //{
            //    if (user1_money > 20)
            //    {
            //        Console.WriteLine("you can come in my store.");
            //    }
            //    else
            //    {
            //        Console.WriteLine("you can not come in my store.");
            //    }

            //}

            //if (user1_age > 10 && user1_money > 20)
            //{
            //    Console.WriteLine("you can come in my store");
            //}
            //else
            //{
            //    Console.WriteLine("you can not come in my store");   // and (&&)   ,  or (||)
            //}




            //int marks;
            //Console.Write("enter your marks : ");
            //marks = int.Parse(Console.ReadLine());



            //if (marks > 34.99 && marks < 51)
            //{
            //    Console.WriteLine("you pass the exam");

            //}
            //else if (81 > marks && marks > 50)
            //{
            //    Console.WriteLine("you got good grade");
            //}
            //else if (marks > 80)
            //{
            //    Console.WriteLine("you got a fanctastic grade");
            //}
            //else
            //{
            //    Console.WriteLine("enter velid marks");
            //}




            //int user_input;
            //Console.Write("enter your number : ");
            //user_input = int.Parse(Console.ReadLine());

            //string check = (user_input == 2) ? "your number is two." : "your number is not two.";
            //Console.WriteLine(check);



            //int[] karan = {1, 2, 3, 4, 5} ;

            //if (karan[2] == 3)
            //{
            //    Console.WriteLine(karan[3]);
            //}


            //string username = "";
            //Console.Write("enter your name : ");
            //username = Console.ReadLine();

            //switch (username)
            //{
            //    case "karan":
            //        Console.WriteLine("you are great karan sir");
            //        break;

            //    case "anita":
            //        Console.WriteLine("Hello karan's mother");
            //        break;

            //    case "meet":
            //        Console.WriteLine("Hello karan's brother.");
            //        break;

            //    case "dinesh":
            //        Console.WriteLine("Hello karan's father.");
            //        break;

            //    default:
            //        Console.WriteLine($"Hey {username} you fool who told you to start this program.");
            //        break;
            //}

            //Console.ReadLine();


            //int st = 1;
            //int num;
            //Console.Write("enter your number : ");
            //num = int.Parse(Console.ReadLine());

            //while (st < num + 1)
            //{
            //    Console.WriteLine("Hello World");
            //    st = st + 1;
            //}

            //Console.ReadLine();


            //int num;
            //Console.Write("enter your number : ");
            //num = int.Parse(Console.ReadLine());

            //do
            //{
            //    Console.WriteLine("hi karan");
            //    num = num + 1;
            //} while (num <= 5);

            //Console.ReadLine();




            //while (true)
            //{
            //    int user_num;
            //    Console.Write("enter your number : ");
            //    user_num = int.Parse(Console.ReadLine());

            //    for (int st = 1; st < user_num + 1; st++)
            //    {
            //        Console.WriteLine($"hello karan {st}.");
            //    }

            //}



            //int[] abc = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            //foreach (int a in abc)
            //{
            //    Console.WriteLine(a);
            //}

            //Console.ReadLine();



            // var (variable)  = compilertime variable
            // dynamic (variable) = runtime variable 



            //karan(3);   // method che je niche lakhi che.   // pass by value




            //var t1 = "How are you ? : ";
            //var t2 = "";
            //var t3 = "fine";
            //var t4 = "You are are Always Fine!!";             // pass by reference
            //var t5 = "Why ? What happen ? : ";                // pass by out my same , ref = out , differ = variable ni value initialize karavi  
            //talk(ref t1, ref t2, ref t3, ref t4, ref t5);





            // optional parameter : means default value method ma set karavi to jo user na pan value aape to error na aave
            // ex. static void karan(int age = "0")  





            //int[] kar = { 1, 11, 21, 31, 41, 51, 61 };        // method niche che.
            //arrayunpacking(kar);




            // perameter ma var (variable) na vaparay and dynamic (variable) vaparay , because var varati vakhate value initialize karavi jaruri che.



            //int a;
            //int b;
            //Console.Write("enter your first number : ");
            //a = int.Parse(Console.ReadLine());
            //Console.Write("enter your second number : ");           // method niche che.
            //b = int.Parse(Console.ReadLine());


            //int s = Saravalo(a, b);
            //Console.WriteLine($"sum : {s}");

            //Console.ReadLine();



            //int a;
            //Console.Write("enter your number : ");
            //a = int.Parse(Console.ReadLine());

            //Check(a);




            //string name ;
            //Console.Write("enter your name : ");
            //name = Console.ReadLine();

            //string key;
            //Console.Write("Male : press 0  , Female : 1 : ");
            //key = Console.ReadLine();



            //if (key == "0")
            //{
            //    Ge gen = Ge.Male;
            //    Console.WriteLine($"Hi {name} you are {gen}");

            //}
            //else
            //{
            //    Ge gen = Ge.Female;
            //    Console.WriteLine($"Hi {name} you are {gen}");

            //}

            // second way

            //string name;
            //Console.Write("enter your name : ");
            //name = Console.ReadLine();

            //int key;
            //Console.Write("Male : press 0  , Female : 1 : ");
            //key = int.Parse(Console.ReadLine());

            //Ge gen;
            //gen = (Ge)key;

            //Console.WriteLine($"hii my name {name} , i am {gen}");




            //enum with switch
            //string name;
            //int key;
            //Week_day day;

            //Console.Write("enter your name : ");
            //name = Console.ReadLine();

            //Console.Write("enter your favourite day (start : 1) : ");
            //key = int.Parse(Console.ReadLine());

            //day = (Week_day)key;

            //Console.WriteLine($"hi {name}");
            //Console.ReadLine();

            // short cut tric  1.switch  2.tab + tab   3.variable nu name ahi day  4. enter    pachi tame andar codeing tamari rite kari shako

            //switch (day)
            //{
            //    case Week_day.monday:
            //        break;
            //    case Week_day.tuesday:
            //        break;
            //    case Week_day.wednesday:
            //        break;
            //    case Week_day.thursday:
            //        break;
            //    case Week_day.friday:
            //        break;
            //    case Week_day.saturday:
            //        break;
            //    case Week_day.sunday:
            //        break;
            //    default:
            //        break;
            //}



            //Student std = new Student();
            //std.age = 10;
            //std.name = "karan";

            //Console.WriteLine(std.age);
            //Console.WriteLine(std.name);



            // method in struct

            //Student std = new Student();
            //std.Display();



            // jo method mate static na lagao to =  Program pr = new Program;  
            //                                      pr.karan();           and jo static lagao to    karan();  .




        }

        //static void karan(int time)
        //{
        //    var user_name = "";
        //    Console.Write("enter your name : ");
        //    user_name = Console.ReadLine();

        //    if (user_name == "karan")
        //    {
        //        for (int st = 1; st < time + 1 ; st++)
        //        {
        //            Console.WriteLine("Hello Sir, How Are You Today ?");
        //        }

        //    }
        //}

        //static void talk(ref string t1,ref string t2,ref string t3,ref string t4,ref string t5)
        //{


        //    Console.Write(t1);
        //    t2 = Console.ReadLine();
        //    if (t2 == t3)
        //    {
        //        Console.WriteLine(t4);
        //    }
        //    else
        //    {
        //        Console.WriteLine(t5);
        //    }

        //}



        //static void arrayunpacking(int[] karray)
        //{
        //    foreach (var ar in karray)
        //    {
        //        Console.WriteLine(ar);
        //    }
        //}



        //static int Saravalo(int i, int j)        // void hoy to koi value return na thay.
        //{                                        // int value return karavi hoy to int lakho em (int, string ,float,double, var,dynamic...)
        //    int sum;                             // void thi pan return kari shakay.
        //    sum = i + j;                         // aapade image , video pan return karavanu hoy.
        //    return sum;                          // return ni sathe method close thai jay pachi niche no code exicute na thay.ex. ni che.
        //}




        //static void Check(int i)
        //{
        //    if (i < 10)
        //    {
        //        Console.WriteLine("hiii i am in side");
        //        return;
        //    }

        //    Console.WriteLine("Hii code is working!!");

        //}





        //enum Ge {Male,Female};        //enum ma e value hoy je change na karay.  jo male ne 0 na badale 1 this ke bija koi num thi start karavi hoy to  [ enum Ge {Male = 1,Female} ] pachi female ni auto alphabaticaly vadhi ne 2 thai jay.

        //enum Week_day {monday = 1,tuesday,wednesday,thursday,friday,saturday,sunday}


        static void karan()
        {
            Console.WriteLine("hi karan ");
        }


     


    }

    //struct Student
    //{
    //    public string name;
    //    public int age;
    //}


    //struct Student
    //{
    //    public string name;
    //    public int age;

    //    public void Display()
    //    {
    //        Console.Write("enter your name : ");
    //        name = Console.ReadLine();
    //        Console.Write("enter your age : ");
    //        age = int.Parse(Console.ReadLine());
    //        Console.WriteLine($"name : {name}");
    //        Console.WriteLine($"age : {age}");
    //    }
    //}



}