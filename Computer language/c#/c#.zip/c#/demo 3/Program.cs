﻿using System;

namespace demo_3
{
    class Program
    {
        static void Main(string[] args)
        {
            // struct = stack
            // class = heap

            Student st = new Student();
            st.marks = 100;

            Student st2 = st;
            Student st3 = st;
            st.marks = 99;

            Console.WriteLine($"{st.marks},{st2.marks},{st3.marks}");   //class use thi traney ma 99 and struct na use thi 99,100,100.
        }
    }

    class Student
    {
       public string name;    
       public int marks;
    }
}
