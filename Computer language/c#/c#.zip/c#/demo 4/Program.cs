﻿using System;
using demo_4.com.studentmanagement;

namespace demo_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //solution explorer ma classes in folder
            // 1. folder banavo (ex.com)  2. module etle folderbanavo (ex.studentmanagement)  3. class banavo (ex.student)   4. ctr + , davai main type kari enter maro and using kari pelano namespace copy kari paste kari do.

            Student stu = new Student();
            stu.age = 17;
            stu.name = "karan";
            stu.roll_no = 17;
            stu.marks = 74;

            stu.Display();

        }
    }
}
