﻿using System;
using System.Collections.Generic;
using System.Text;

namespace demo_4.com.studentmanagement
{
    class Student
    {
        public string name;
        public int age;
        public int roll_no;
        public int marks;

        public void Display()
        {
            Console.WriteLine($"name : {name} , age : {age} , roll no : {roll_no} , marks : {marks}.");
        }


    }

    
}
