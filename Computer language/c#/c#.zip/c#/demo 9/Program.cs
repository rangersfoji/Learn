﻿using System;

namespace demo_9
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("hiii my name is karan");

            

        }
    }
}




                        


                    
                        

                            

                        

                    

