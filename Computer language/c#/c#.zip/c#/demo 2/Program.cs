﻿using System;

namespace demo_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Student st = new Student();
            st.name = "karan";
            st.age = 17;
            st.marks = 74;

            st.display();
        }
    }

    class Student
    {
        public string name;
        public int age;
        public int marks;

        public void display()
        {
            Console.WriteLine($"name : {name} , age : {age} , marks : {marks}.");
        }
    }
}
